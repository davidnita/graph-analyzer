GRAPH ANALYZER — Niță David Gabriel / Dumitrache David / XII A

1. Deschide index.html în browser.
2. În pagina C++ se afișează codul original proiect.cpp.
3. Testele sunt în test1.txt, test2.txt, test3.txt.
4. Compilează separat: g++ -std=c++17 proiect_extins.cpp -o proiect
5. Rulează: ./proiect < test1.txt (Windows: proiect.exe < test1.txt)
6. Link public: nu este încă publicat; poți folosi GitHub Pages pentru index.html.
7. Prezentarea PPTX este în directorul principal.
