#include <iostream>
#include <vector>
using namespace std;

int main() {
    int n, m;
    if (!(cin >> n >> m) || n < 1 || n > 200 || m < 0 || m > n*n) {
        cerr << "Date initiale invalide\n"; return 1;
    }
    vector<vector<int>> A(n+1, vector<int>(n+1, 0));
    for (int e=0; e<m; ++e) {
        int u,v;
        if (!(cin >> u >> v) || u<1 || u>n || v<1 || v>n) {
            cerr << "Arc invalid la linia " << e+1 << "\n"; return 1;
        }
        A[u][v]=1;
    }
    auto printMatrix = [&](const vector<vector<int>>& M, const char* title) {
        cout << title << "\n";
        for(int i=1;i<=n;i++){for(int j=1;j<=n;j++) cout << M[i][j] << ' '; cout << '\n';}
    };
    printMatrix(A,"Matricea de adiacenta:");
    vector<vector<int>> D=A;
    for(int i=1;i<=n;i++) D[i][i]=1; // drum de lungime zero
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                D[i][j] = D[i][j] || (D[i][k] && D[k][j]);
    printMatrix(D,"Matricea drumurilor:");
    vector<bool> seen(n+1,false);
    cout << "Componentele tare conexe sunt:\n";
    for(int i=1;i<=n;i++) if(!seen[i]) {
        cout << "{ ";
        for(int j=1;j<=n;j++) if(D[i][j] && D[j][i]) {
            cout << j << ' '; seen[j]=true;
        }
        cout << "}\n";
    }
}
