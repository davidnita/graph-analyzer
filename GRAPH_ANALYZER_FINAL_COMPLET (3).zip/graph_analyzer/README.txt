GRAPH ANALYZER — VERSIUNEA 2

1. Deschide index.html în Chrome/Edge (funcționează offline).
2. Dashboard: prezentare grafică a rețelei și statisticilor.
3. Laborator: încarcă testele, adaugă/șterge arce, parcurge pașii Roy–Warshall.
4. Fișiere de test: rulează sau descarcă cele trei exemple.
5. Program C++: încarcă local codul real al colegului și introdu linkul spre repository. Datele nu sunt încărcate pe server și nu se salvează permanent.
6. Teorie: definiții, formulă, complexitate.

IMPORTANT: interfața web calculează independent în JavaScript. Nu execută programul C++. Pentru predare, adăugați fișierul C++ real și linkul în PowerPoint.

FORMAT TEST: prima linie n m, apoi m linii u v.
